package com.zerobank.qa.testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zerobank.qa.base.Base;
import com.zerobank.qa.pages.AccountSummaryPage;
import com.zerobank.qa.pages.FundTransferPage;
import com.zerobank.qa.pages.HomePage;
import com.zerobank.qa.pages.LoginPage;

public class AccountSummaryPageTest extends Base {
	
	LoginPage loginPage;
	HomePage homePage;
	AccountSummaryPage accountSummaryPage;
	FundTransferPage fundTransferPage;
	
	public AccountSummaryPageTest() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		loginPage = new LoginPage();
		homePage = new HomePage();
		accountSummaryPage = new AccountSummaryPage();
		fundTransferPage = new FundTransferPage();
	}
	
	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();
	}
	
	@Test
	private void validateAccountSummaryPage() {
		homePage.clickOnSignInButton();
		loginPage.login();
		accountSummaryPage.assertAccountSummaryPagTitle();

	}
	
	@Test
	private void clickOnTransferFundsTest() {
		fundTransferPage = accountSummaryPage.clickOnFundTransfer();
		fundTransferPage.assertFundTransferPageTitle();
	}
	

}
