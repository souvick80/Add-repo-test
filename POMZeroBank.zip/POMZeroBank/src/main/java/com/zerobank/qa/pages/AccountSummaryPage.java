package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class AccountSummaryPage extends Base{
	
	@FindBy(id="pay_bills_tab") WebElement pay_bills_tab;
	@FindBy(id="transfer_funds_tab") WebElement transfer_funds_tab;
	
	public AccountSummaryPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertAccountSummaryPagTitle() {
		assertEquals(driver.getTitle(), "Zero - Account Summary");
	}
	
	public PayBillsPage clickOnPayBillsTab() {
		pay_bills_tab.click();
		return new PayBillsPage();

	}
	
	public FundTransferPage clickOnFundTransfer() {
		transfer_funds_tab.click();
		return new FundTransferPage();

	}

}
