package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class PurchaseForeignCurrencyPage extends Base {
	
	@FindBy(id = "purchase_cash") WebElement purchaseButton;
	@FindBy(xpath = "//h2[contains(text(),'Purchase foreign currency')]") WebElement header;
	
	public PurchaseForeignCurrencyPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertPayBillsPageHeader() {
		assertEquals(header.getText(), "Purchase foreign currency cash");
	}

	public void clickOnPurchaseButton() {
		purchaseButton.click();

	}
}
