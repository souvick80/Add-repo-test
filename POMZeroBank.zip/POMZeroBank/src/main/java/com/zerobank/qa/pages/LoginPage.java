package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class LoginPage extends Base{
	
	@FindBy(name = "user_login") WebElement userIdTextBox;
	@FindBy(id = "user_password") WebElement passwordTextBox;
	@FindBy(id = "user_remember_me") WebElement rememberMeCheckBx;
	@FindBy(name = "submit") WebElement logInButton;
	@FindBy(id="details-button") WebElement detailsButton;
	@FindBy(id="proceed-link") WebElement proceedToLink;
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Log in");
	}
	
	public AccountSummaryPage login() {
		userIdTextBox.sendKeys("username");
		passwordTextBox.sendKeys("password");
		rememberMeCheckBx.click();
		logInButton.click();
		detailsButton.click();
		proceedToLink.click();
		return new AccountSummaryPage();
		
		
	}
	

}
