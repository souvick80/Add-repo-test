package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class PayBillsPage extends Base{
	
	@FindBy(linkText = "Purchase Foreign Currency") WebElement foreignCurrencyTab;
	
	
	public PayBillsPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertPayBillsPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
	}
	
	public PurchaseForeignCurrencyPage clickOnPurchaseForeignCurrencyTab() {
		foreignCurrencyTab.click();
		return new PurchaseForeignCurrencyPage();

	}
	

}
