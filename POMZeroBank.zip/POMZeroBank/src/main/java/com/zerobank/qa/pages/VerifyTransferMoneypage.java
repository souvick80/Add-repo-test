package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class VerifyTransferMoneypage extends Base{
	
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments - Verify')]") WebElement header;
	
	public VerifyTransferMoneypage() {
		PageFactory.initElements(driver, this);
	}
	
	private void assertVerifyTransferMoneypageHeader() {
		assertEquals(header.getText(), "Transfer Money & Make Payments - Verify");
	}
	
	
}